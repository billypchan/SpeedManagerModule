//
//  SpeedManagerModule.h
//  SpeedManagerModule
//
//  Created by Swift Package Manager.
//

#import <Foundation/Foundation.h>

//! Project version number for SpeedManagerModule.
FOUNDATION_EXPORT double SpeedManagerModuleVersionNumber;

//! Project version string for SpeedManagerModule.
FOUNDATION_EXPORT const unsigned char SpeedManagerModuleVersionString[];
